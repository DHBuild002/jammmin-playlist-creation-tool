import React from "react";
import "../styles/TrackList.css";

import Track from "./Track";

const TrackList = (props) => {
  return (
    <div className="TrackList">
      {props.map((track) => {
        return (
          <Track
            track={track}
            key={track.id}
            onAdd={props.onAdd}
            isRemoval={props.isRemoval}
            onRemove={props.onRemove}
          />
        );
      })}
    </div>
  );
};

export default TrackList;
